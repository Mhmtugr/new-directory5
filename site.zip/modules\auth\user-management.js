// Yeni oluşturulacak dosya, içeriği ekleyin
// Örnek içerik
// async function manageUser() { ... } 